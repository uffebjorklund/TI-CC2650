using XSockets.Core.Common.Interceptor;
using XSockets.Core.Common.Protocol;
using XSockets.Core.Common.Socket.Event.Interface;

namespace $rootnamespace$
{
    public class $safeitemrootname$ : IMessageInterceptor
    {
        public void OnIncomingMessage(IXSocketProtocol protocol, IMessage message)
        {

        }

        public void OnOutgoingMessage(IXSocketProtocol protocol, IMessage message)
        {

        }
    }
}
