using System.Security.Principal;
using XSockets.Core.Common.Protocol;
using XSockets.Core.Common.Socket;
using XSockets.Plugin.Framework.Attributes;

namespace $rootnamespace$
{
    [Export(typeof(IXSocketAuthenticationPipeline))]
    public class $safeitemrootname$ : IXSocketAuthenticationPipeline
    {
        public IPrincipal GetPrincipal(IXSocketProtocol protocol)
        {

            if (protocol.ConnectionContext.User == null)
            {
                //fake, implement your own logic to set the User 
                var roles = new string[] { "superman", "hulk" };
                var userIdentity = new GenericIdentity("David");
                protocol.ConnectionContext.User = new GenericPrincipal(userIdentity, roles);
            }

            return protocol.ConnectionContext.User;
        }
    }
}
