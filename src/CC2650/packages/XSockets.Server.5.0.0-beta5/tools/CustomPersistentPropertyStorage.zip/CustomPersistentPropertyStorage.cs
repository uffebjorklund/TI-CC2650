using System;
using XSockets.Core.XSocket;

namespace $rootnamespace$
{    
    public class $safeitemrootname$ : PersistentPropertyStorage
    {
        public override void ReadFromPropertyStorage<T>(T controller)
        {
            throw new NotImplementedException("Implement custom storage for property values");
        }

        public override void WriteToPropertyStorage<T>(T controller)
        {
            throw new NotImplementedException("Implement custom storage for property values");
        }
    }
}
