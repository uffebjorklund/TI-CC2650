using System;
using XSockets.Core.Common.Socket.Event.Interface;
using XSockets.Enterprise.Scaling;

namespace $rootnamespace$
{    
    public class $safeitemrootname$ : BaseScaleOut
    {
        /// <summary>
        /// Called at startup, setup/prepare your scaleout
        /// </summary>
        public override void Init()
        {            
            throw new NotImplementedException();
        }

        /// <summary>
        /// Publish the message to the scaleout so that other servers can receive it
        /// </summary>
        /// <param name="message"></param>
        public override void Publish(IMessage message)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Subscribe for messages published from other servers by using AzureServiceBus or similar techniques
        /// 
        /// You can ofcourse do polling to a data source, but performance will be suffering from that.
        /// </summary>
        public override void Subscribe()
        {
            throw new NotImplementedException();
        }
    }
}
