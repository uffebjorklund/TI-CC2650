using System;
using XSockets.Core.Common.Interceptor;

namespace $rootnamespace$
{
    public class $safeitemrootname$ : IErrorInterceptor
    {
        public void OnError(Exception exception)
        {
            
        }
    }
}
