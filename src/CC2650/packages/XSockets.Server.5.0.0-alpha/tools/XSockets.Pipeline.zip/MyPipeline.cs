using XSockets.Core.Common.Socket;
using XSockets.Core.Common.Socket.Event.Interface;
using XSockets.Core.XSocket;

namespace $rootnamespace$
{
     public class $safeitemrootname$ : XSocketPipeline
    {
        public override void OnIncomingMessage(IXSocketController controller, IMessage e)
        {
            base.OnIncomingMessage(controller, e);
        }

        public override IMessage OnOutgoingMessage(IXSocketController controller, IMessage e)
        {
            return base.OnOutgoingMessage(controller, e);
        }
    }
}
