using System.Diagnostics;
using XSockets.Core.Common.Interceptor;
using XSockets.Core.Common.Protocol;

namespace $rootnamespace$
{
    /// <summary>
    /// Remeber to install XSockets.PerformanceCounters from Chocolatey.org
    /// cinst XSockets.PerformanceCounters    
    /// </summary>
    public class $safeitemrootname$ : IConnectionInterceptor
    {
        private static readonly PerformanceCounter ConnectionCounter;
        private static readonly PerformanceCounter HandshakeInvalidCounter;
        private static readonly PerformanceCounter HandshakeValidCounter;
        private static readonly PerformanceCounter HandshakeValidSecCounter;
        private static readonly PerformanceCounter HandshakeInvalidSecCounter;

        static $safeitemrootname$()
        {
            ConnectionCounter = new PerformanceCounter("XSockets.NET", "CURRENT-CONNECTIONS", "XSockets.NET", false);
            HandshakeInvalidCounter = new PerformanceCounter("XSockets.NET", "TOTAL-INVALID-HANDSHAKES", "XSockets.NET", false);
            HandshakeValidCounter = new PerformanceCounter("XSockets.NET", "TOTAL-VALID-HANDSHAKES", "XSockets.NET", false);
            HandshakeInvalidSecCounter = new PerformanceCounter("XSockets.NET", "INVALID-HANDSHAKES/SEC", "XSockets.NET", false);
            HandshakeValidSecCounter = new PerformanceCounter("XSockets.NET", "VALID-HANDSHAKES/SEC", "XSockets.NET", false);            
        }

        public void Connected(IXSocketProtocol protocol)
        {            
            ConnectionCounter.IncrementBy(1);
        }

        public void Disconnected(IXSocketProtocol protocol)
        {
            
            ConnectionCounter.IncrementBy(-1);
        }

        public void HandshakeCompleted(IXSocketProtocol protocol)
        {
            HandshakeValidCounter.IncrementBy(1);
            HandshakeValidSecCounter.IncrementBy(1);
        }

        public void HandshakeInvalid(string rawHandshake)
        {
            HandshakeInvalidCounter.IncrementBy(1);
            HandshakeInvalidSecCounter.IncrementBy(1);
        }
    }
}
