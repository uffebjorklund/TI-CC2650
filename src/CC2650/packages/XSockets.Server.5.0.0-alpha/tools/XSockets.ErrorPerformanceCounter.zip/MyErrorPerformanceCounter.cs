using System;
using System.Diagnostics;
using XSockets.Core.Common.Interceptor;

namespace $rootnamespace$
{
    /// <summary>
    /// Remeber to install XSockets.PerformanceCounters from Chocolatey.org
    /// cinst XSockets.PerformanceCounters    
    /// </summary>
    public class $safeitemrootname$ : IErrorInterceptor
    {
        private static readonly PerformanceCounter ErrorsCounter;
        private static readonly PerformanceCounter ErrorsPerSecCounter;
        static $safeitemrootname$()
        {
            ErrorsCounter = new PerformanceCounter("XSockets.NET", "TOTAL-ERRORS", "XSockets.NET", false);
            ErrorsPerSecCounter = new PerformanceCounter("XSockets.NET", "ERRORS/SEC", "XSockets.NET", false);
        }
        public void OnError(Exception exception)
        {
            ErrorsCounter.IncrementBy(1);
            ErrorsPerSecCounter.IncrementBy(1);
        }
    }
}
